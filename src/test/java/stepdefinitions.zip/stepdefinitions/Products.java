package stepdefinitions;

import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import static org.junit.Assert.assertEquals;

import utility.JsonUtils;

import java.io.IOException;

public class Products {

    private Response response;
    private RequestSpecification http_request;
    private int responseCode;
    private ResponseBody body;

    //  Step 1: Set Base URI
    @Given("I hit the get product url")
    public void I_hit_the_get_product_url() {
        RestAssured.baseURI = "https://fakestoreapi.com";
    }

    //  Step 2: Perform GET
    @When("Check the get product ID response")
    public void check_the_get_product_id_response() {
        http_request = given();
        response = http_request.get("products");
    }

    //  Step 3: Verify status code
    @And("verify the status code {int}")
    public void verify_the_status_code_code(Integer expectedStatus) {
        responseCode = response.getStatusCode();

        // Convert Integer wrapper to primitive int
        assertEquals(" Status code mismatch!", expectedStatus.intValue(), responseCode);
        System.out.println(" Success code: " + responseCode);
    }

    //  Step 4: Validate Schema
    @Then("validate the schema")
    public void validate_the_schema() {
        response.then().assertThat()
                .body(matchesJsonSchemaInClasspath("schemas/products-schema.json"));
        System.out.println(" Schema validation passed!");
    }

    //  Step 5: Hit a specific product endpoint
    @Given("I hit the get product url api endpoint {int}")
    public void i_hit_the_get_product_url_api_endpoint(Integer productId) {
        RestAssured.baseURI = "https://fakestoreapi.com";
        http_request = given();
        response = http_request.get("products/" + productId);
    }

    //  Step 6: Verify rate and ID
    @Then("I verify the rate of the {double} product")
    public void i_verify_the_rate_of_the_product(double expectedRate) {
        // Status check
        responseCode = response.getStatusCode();
        assertEquals(" Expected status code 200", 200, responseCode);

        // Parse response
        body = response.getBody();
        JsonPath jsp = response.jsonPath();

        // Extract values
        double actualRate = jsp.getDouble("rating.rate");
        int actualId = jsp.getInt("id");

        assertEquals(" Rate does not match!", expectedRate, actualRate, 0.01);

        //  Compare IDs
        assertEquals(" ID does not match!", 1, actualId);

        System.out.println(" Rate: " + actualRate + " | ID: " + actualId);
    }

    //  Step 7: POST request with body
    @When("I pass the request body {string} {int}")
    public void i_pass_the_request_body_filename(String fileName, Integer expectedCode) throws IOException {
        //  Read JSON using utility
        String body = JsonUtils.readJson(fileName);

        //  Execute POST call
        response = given()
                .log().all()
                .contentType(ContentType.JSON)
                .body(body)
                .when()
                .post("/products")
                .then()
                .log().all()
                .statusCode(expectedCode)
                .extract()
                .response();

        System.out.println(" POST request executed successfully with status code: " + expectedCode);
    }
}
